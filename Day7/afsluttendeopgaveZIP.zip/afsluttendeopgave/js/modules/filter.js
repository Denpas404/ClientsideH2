const ignor = [
    "films",
    "species",
    "vehicles",
    "starships",
    "created",
    "edited",
    "residents",
    "characters",
    "planets",
    "pilots",
    "people" 
]

export {ignor};